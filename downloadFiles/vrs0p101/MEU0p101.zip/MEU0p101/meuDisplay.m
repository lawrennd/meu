function meuDisplay(model, spacing)

% MEUDISPLAY Display parameters of the MEU model.
%
%	Description:
%
%	MEUDISPLAY(MODEL) displays the parameters of the maximum entropy
%	unfolding model and the model type to the console.
%	 Arguments:
%	  MODEL - the model to display.
%
%	MEUDISPLAY(MODEL, SPACING)
%	 Arguments:
%	  MODEL - the model to display.
%	  SPACING - how many spaces to indent the display of the model by.
%	
%
%	See also
%	MEUCREATE, MODELDISPLAY


%	Copyright (c)  Neil D. Lawrence 2009
% 	meuDisplay.m SVN version 985
% 	last update 2010-05-26T05:49:09.000000Z

  if nargin > 1
    spacing = repmat(32, 1, spacing);
  else
    spacing = [];
  end
  spacing = char(spacing);
  fprintf(spacing);
  fprintf('Maximum entropy unfolding model:\n')
  fprintf(spacing);
  fprintf('  Neighbours: %d\n', model.k);
end
function options = drillOptions(neighbours)

% DRILLOPTIONS Options for a DRILL model.
%
%	Description:
%
%	OPTIONS = DRILLOPTIONS(NEIGHBOURS) returns the default options for
%	the drill model.
%	 Returns:
%	  OPTIONS - default options structure for the DRILL.
%	 Arguments:
%	  NEIGHBOURS - the number of neighbours to use.
%	
%
%	See also
%	DRILLCREATE, MODELCREATE


%	Copyright (c) 2010 Neil D. Lawrence
% 	drillOptions.m SVN version 985
% 	last update 2010-06-03T22:15:08.000000Z

  if nargin < 1
    neighbours = 7;
  end
  options.numNeighbours = neighbours;
  options.isNormalised = true;
  options.regulariser = 1.0;
  options.regulariserType = 'none';
end
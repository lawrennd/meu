function model = meuCreate(inputDim, outputDim, Y, options)

% MEUCREATE Create a MEU model.
%
%	Description:
%
%	MODEL = MEUCREATE(INPUTDIM, OUTPUTDIM, Y, OPTIONS) creates a maximum
%	entropy unfolding model structure given an options structure.
%	 Returns:
%	  MODEL - the model structure with the default parameters placed in.
%	 Arguments:
%	  INPUTDIM - the input dimension of the model.
%	  OUTPUTDIM - the output dimension of the model.
%	  Y - the data to be modelled in design matrix format (as many rows
%	   as there are data points).
%	  OPTIONS - an options structure that determines the form of the
%	   model.
%	
%
%	See also
%	MEUOPTIONS, MODELCREATE


%	Copyright (c)  Neil D. Lawrence 2009
% 	meuCreate.m SVN version 985
% 	last update 2010-05-26T05:49:09.000000Z

model.type = 'meu';

if size(Y, 2) ~= outputDim
  error(['Input matrix Y does not have dimension ' num2str(d)]);
end
model.isNormalised = options.isNormalised;
model.regulariser = options.regulariser;
model.k = options.numNeighbours;
model.Y = Y;
model.d = outputDim;
model.q = inputDim;
model.N = size(Y, 1);
model.sigma2 = options.sigma2;
model.sigma2Fixed = true;
model.kappaTransform = optimiDefaultConstraint('positive');
model.sigma2Transform = optimiDefaultConstraint('positive');
model = meuParamInit(model);

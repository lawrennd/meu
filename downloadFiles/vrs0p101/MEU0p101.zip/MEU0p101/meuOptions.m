function options = meuOptions(neighbours, sigma2)

% MEUOPTIONS Create a default options structure for the MEU model.
%
%	Description:
%
%	OPTIONS = MEUOPTIONS(NEIGHBOURS, SIGMA2) creates a default options
%	structure for the probabilistic maximum variance unfolding model
%	structure.
%	 Returns:
%	  OPTIONS - the default options structure.
%	 Arguments:
%	  NEIGHBOURS - the number of neighbours to use.
%	  SIGMA2 - noise level.
%	
%
%	See also
%	MEUCREATE, MODELOPTIONS


%	Copyright (c)  Neil D. Lawrence 2009
% 	meuOptions.m SVN version 985
% 	last update 2010-05-26T05:49:09.000000Z

  if nargin < 1
    neighbours = 7;
  end
  options.numNeighbours = neighbours;
  options.isNormalised = false;
  options.regulariser = 0.0;
  if nargin<2
    options.sigma2 = 0.0;
  else
    options.sigma2 = sigma2;
  end
end

function drillInfo = drillDeconstruct(model)

% DRILLDECONSTRUCT break DRILL in pieces for saving.
%
%	Description:
%
%	DRILLINFO = DRILLDECONSTRUCT(MODEL) takes an DRILL model structure
%	and breaks it into component parts for saving.
%	 Returns:
%	  DRILLINFO - a structure containing the other information from the
%	   maximum entropy unfolding.
%	 Arguments:
%	  MODEL - the model that needs to be saved.
%	
%
%	See also
%	DRILLCREATE, DRILLRECONSTRUCT


%	Copyright (c)  Neil D. Lawrence 2010
% 	drillDeconstruct.m SVN version 985
% 	last update 2010-05-28T10:08:08.000000Z


  drillInfo = model;
  removeFields = {'Y'};
  
  for i = 1:length(removeFields)
    if isfield(drillInfo, removeFields{i})
      drillInfo = rmfield(drillInfo, removeFields{i});
    end
  end
end

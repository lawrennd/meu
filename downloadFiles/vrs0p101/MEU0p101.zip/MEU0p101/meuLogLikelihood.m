function ll = meuLogLikelihood(model)

% MEULOGLIKELIHOOD Log likelihood of MEU model.
%
%	Description:
%
%	LL = MEULOGLIKELIHOOD(MODEL) computes the log likelihood of  the
%	maximum entropy unfolding model.
%	 Returns:
%	  LL - the computed log likelihood.
%	 Arguments:
%	  MODEL - the model structure for which log likelihood is being
%	   computed.
%	
%
%	See also
%	MEUCREATE, MEULOGLIKEGRADIENTS, MODELLOGLIKELIHOOD


%	Copyright (c)  Neil D. Lawrence 2009
% 	meuLogLikelihood.m SVN version 985
% 	last update 2010-05-26T05:49:09.000000Z

  if model.sigma2 == 0
    ll = -model.d*model.logDetK;
    ll = ll - sum(sum(model.Y.*((model.L*model.Y)+model.gamma*model.Y)));

  else
    ll = -model.d*model.logDetSigma;
    ll = ll - sum(sum(model.Y.*(model.invSigma*model.Y)));
  end
  ll = ll*0.5;
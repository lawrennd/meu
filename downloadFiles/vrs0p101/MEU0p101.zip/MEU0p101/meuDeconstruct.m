function meuInfo = meuDeconstruct(model)

% MEUDECONSTRUCT break MEU in pieces for saving.
%
%	Description:
%
%	MEUINFO = MEUDECONSTRUCT(MODEL) takes an maximum entropy unfolding
%	model structure and breaks it into component parts for saving.
%	 Returns:
%	  MEUINFO - a structure containing the other information from the
%	   maximum entropy unfolding.
%	 Arguments:
%	  MODEL - the model that needs to be saved.
%	
%
%	See also
%	MEUCREATE, MEURECONSTRUCT


%	Copyright (c)  Neil D. Lawrence 2009
% 	meuDeconstruct.m SVN version 985
% 	last update 2010-05-28T10:08:22.000000Z


  meuInfo = model;
  removeFields = {'Y'};
  
  for i = 1:length(removeFields)
    if isfield(meuInfo, removeFields{i})
      meuInfo = rmfield(meuInfo, removeFields{i});
    end
  end
end

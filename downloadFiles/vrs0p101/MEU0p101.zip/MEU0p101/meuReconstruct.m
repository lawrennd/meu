function model = meuReconstruct(meuInfo, y)

% MEURECONSTRUCT Reconstruct an maximum entropy unfolding from component parts.
%
%	Description:
%
%	MODEL = MEURECONSTRUCT(MEUINFO, Y) takes component parts of an
%	maximum entropy unfolding model and reconstructs the maximum entropy
%	unfolding model. The component parts are normally retrieved from a
%	saved file.
%	 Returns:
%	  MODEL - an maximum entropy unfolding model structure that combines
%	   the component parts.
%	 Arguments:
%	  MEUINFO - the active set and other information stored in a
%	   structure.
%	  Y - the output target training data for the maximum entropy
%	   unfolding.
%	
%
%	See also
%	MEUCREATE, MEURECONSTRUCT


%	Copyright (c)  Neil D. Lawrence 2009
% 	meuReconstruct.m SVN version 985
% 	last update 2010-05-26T05:49:09.000000Z

  model = meuInfo;
  model.Y = y;
  
end
function g = meuLogLikeGradients(model)

% MEULOGLIKEGRADIENTS Gradient of MEU model log likelihood with respect to parameters.
%
%	Description:
%
%	G = MEULOGLIKEGRADIENTS(MODEL) computes the gradient of the maximum
%	entropy unfolding model's log likelihood with respect to the
%	parameters.
%	 Returns:
%	  G - the returned gradients.
%	 Arguments:
%	  MODEL - model structure for which gradients are being computed.
%	
%
%	See also
%	% SEEALSO MEUCREATE, MEULOGLIKELIHOOD, MODELLOGLIKEGRADIENTS


%	Copyright (c)  Neil D. Lawrence 2009
% 	meuLogLikeGradients.m SVN version 985
% 	last update 2010-05-26T05:49:09.000000Z
  if model.sigma2 == 0.0
    gV = 0.5*( model.d*model.expD2 - model.D2);
  else
    AinvY = model.Ainv*model.Y;
    AinvYYTAinv = AinvY*AinvY';
    for i = 1:model.N
      for j = 1:model.k
        ind = model.indices(i, j);
        gV(i, j) = model.d*(model.AinvLinv(i, i) ...
                            - 2*model.AinvLinv(i, ind) ...
                            + model.AinvLinv(ind, ind));
        gV(i, j) = gV(i, j) - AinvYYTAinv(i, i) ...
            + 2*AinvYYTAinv(i, ind) ...
            - AinvYYTAinv(ind, ind);
      end
    end
    gV = gV*0.5;
  end
  fhandle = str2func([model.kappaTransform 'Transform']);
  factors = fhandle(model.kappa, 'gradfact');
  gV = gV.*factors;
  g = gV(:)';
  
  if ~model.sigma2Fixed
    invSigmaY = model.invSigma*model.Y;
    gS = -model.d*trace(model.invSigma) + sum(sum(invSigmaY.*invSigmaY));
    gS = gS*0.5;
    fhandle = str2func([model.sigma2Transform 'Transform']);
    factor = fhandle(model.sigma2, 'gradfact');
    g(end+1) = gS*factor;
  end
end
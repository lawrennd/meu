% MEU toolbox
% Version 0.101		27-Oct-2010
% Copyright (c) 2010, Neil D. Lawrence
% 
, Neil D. Lawrence
% DEMSTICKDRILL2  Model the stick man with DRILL using 20 neighbors and structure learning.
% DEMSTICKDRILL1 Model the stick man with DRILL using 6 neighbors.
% MEULOGLIKELIHOOD Log likelihood of MEU model.
% DEMROBOTWIRELESSDRILL1 Model the stick man with DRILL using 7 neighbors.
% DEMROBOTWIRELESSLE1 Model the stick man with LE using 7 neighbors.
% MEUCREATE Create a MEU model.
% DEMSTICKMVU1 Model the stick man with MVU using 6 neighbors.
% MEULOGLIKEGRADIENTS Gradient of MEU model log likelihood with respect to parameters.
% DEMROBOTWIRELESSLLE1 Model the stick man with LLE using 7 neighbors.
% MEURECONSTRUCT Reconstruct an maximum entropy unfolding from component parts.
% MEUEXTRACTPARAM Extract parameters from the MEU model structure.
% DEMSTICKDRILL5  Model the stick man with DRILL using 6 neighbors and structure learning.
% DEMSTICKMEU1 Model the stick man with MEU using 6 neighbors.
% DEMSTICKISOMAP1 Model the stick man with isomap using 6 neighbors.
% DRILLOPTIMISE Optimise an DRILL model.
% DEMSTICKDRILL4  Model the stick man with DRILL using different neighbours.
% DEMROBOTWIRELESSMEU1 Model the stick man with MEU using 7 neighbors.
% DEMROBOTWIRELESSMVU1 Model the stick man with MVU using 7 neighbors.
% DRILLRECONSTRUCT Reconstruct an DRILL model..
% MEUGRADIENT Gradient wrapper for a MEU model.
% MEUEXPANDPARAM Create model structure from MEU model's parameters.
% MEUTOOLBOXES Toolboxes required for the MEU demos.
% MEUOBJECTIVEGRADIENT Wrapper function for MEU objective and gradient.
% DRILLCREATE Loglikelihood for dimensinality reduction.
% DEMSTICKLE1 Model the stick man with LE using 6 neighbors.
% MEUDISPLAY Display parameters of the MEU model.
% DEMSTICKDRILL3  Model the stick man with DRILL using full connectivity and structure learning.
% MEUPARAMINIT MEU model parameter initialisation.
% DRILLDECONSTRUCT break DRILL in pieces for saving.
% MEUDECONSTRUCT break MEU in pieces for saving.
% MEUOPTIMISE Optimise maximum entropy unfolding.
% MEUOPTIONS Create a default options structure for the MEU model.
% DRILLOPTIONS Options for a DRILL model.
% DEMROBOTWIRELESSISOMAP1 Model the stick man with isomap using 7 neighbors.
% MEUOBJECTIVE Wrapper function for MEU objective.
% DEMSTICKLLE1 Model the stick man with LLE using 6 neighbors.

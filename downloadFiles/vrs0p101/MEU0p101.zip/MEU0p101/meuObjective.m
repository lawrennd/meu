function f = meuObjective(params, model)

% MEUOBJECTIVE Wrapper function for MEU objective.
%
%	Description:
%
%	F = MEUOBJECTIVE(PARAMS, MODEL) returns the negative log likelihood
%	of a MEU model given the model structure and a vector of parameters.
%	This allows the use of NETLAB minimisation functions to find the
%	model parameters.
%	 Returns:
%	  F - the negative log likelihood of the MEU model.
%	 Arguments:
%	  PARAMS - the parameters of the model for which the objective will
%	   be evaluated.
%	  MODEL - the model structure for which the objective will be
%	   evaluated.
%	
%
%	See also
%	SCG, CONJGRAD, MEUCREATE, MEUGRADIENT, MEULOGLIKELIHOOD, MEUOPTIMISE


%	Copyright (c) 2005, 2006, 2009 Neil D. Lawrence
% 	meuObjective.m SVN version 985
% 	last update 2010-05-26T05:49:09.000000Z

model = meuExpandParam(model, params);
f = - meuLogLikelihood(model);

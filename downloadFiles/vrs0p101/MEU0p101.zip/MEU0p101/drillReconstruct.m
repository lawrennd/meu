function model = drillReconstruct(drillInfo, y)

% DRILLRECONSTRUCT Reconstruct an DRILL model..
%
%	Description:
%
%	MODEL = DRILLRECONSTRUCT(DRILLINFO, Y) takes component parts of a
%	DRILL model and reconstructs the model. The component parts are
%	normally retrieved from a saved file.
%	 Returns:
%	  MODEL - an maximum entropy unfolding model structure that combines
%	   the component parts.
%	 Arguments:
%	  DRILLINFO - the active set and other information stored in a
%	   structure.
%	  Y - the output target training data for the maximum entropy
%	   unfolding.
%	
%
%	See also
%	DRILLCREATE, DRILLRECONSTRUCT


%	Copyright (c)  Neil D. Lawrence 2010
% 	drillReconstruct.m SVN version 985
% 	last update 2010-05-28T10:08:35.000000Z

  model = drillInfo;
  model.Y = y;
  
end
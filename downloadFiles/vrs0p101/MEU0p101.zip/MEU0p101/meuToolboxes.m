
% MEUTOOLBOXES Toolboxes required for the MEU demos.
%
%	Description:
%	% 	meuToolboxes.m SVN version 1020
% 	last update 2010-10-26T22:13:45.650963Z
importLatest('netlab');
importLatest('glmnet');
importLatest('gp');
importLatest('kern');
importLatest('ndlutil');
importLatest('optimi');
importLatest('mocap');
importLatest('prior');
importLatest('datasets');
importLatest('mltools');
%importLatest('synth');
%importLatest('plot2svg');
%importLatest('rotate_image');
%importLatest('m_map');
importLatest('isomap');
importLatest('lle');
importLatest('mvu');
importLatest('sedumi');
importLatest('voicebox');
%importTool('matfig2pgf');
importLatest('L1precision');

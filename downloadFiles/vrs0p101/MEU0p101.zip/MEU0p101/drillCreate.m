function model = drillCreate(inputDim, outputDim, Y, options)

% DRILLCREATE Loglikelihood for dimensinality reduction.
%
%	Description:
%
%	MODEL = DRILLCREATE(LATENTDIMENSION, OUTPUTDIM, Y, OPTIONS) creates
%	a structure for a locally linear embedding.
%	 Returns:
%	  MODEL - model structure containing DRILL model.
%	 Arguments:
%	  LATENTDIMENSION - dimension of latent space.
%	  OUTPUTDIM - dimension of data.
%	  Y - the data to be modelled in design matrix format (as many rows
%	   as there are data points).
%	  OPTIONS - options structure as returned by drillOptions.
%	
%
%	See also
%	DRILLOPTIONS, MODELCREATE


%	Copyright (c) 2010 Neil D. Lawrence
% 	drillCreate.m SVN version 985
% 	last update 2010-06-03T22:15:08.000000Z


model.type = 'drill';

if size(Y, 2) ~= outputDim
  error(['Input matrix Y does not have dimension ' num2str(d)]);
end
model.isNormalised = options.isNormalised;
model.regulariser = options.regulariser;
model.regulariserType = options.regulariserType;
model.k = options.numNeighbours;
model.Y = Y;
model.d = outputDim;
model.q = inputDim;
model.N = size(Y, 1);
model.discardLowest = false; % Don't discard lowest eigenvector of L. (it
                             % won't be the constant zero eigenvector.
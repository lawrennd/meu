function model = meuParamInit(model)

% MEUPARAMINIT MEU model parameter initialisation.
%
%	Description:
%
%	MODEL = MEUPARAMINIT(MODEL) initialises the maximum entropy
%	unfolding model structure with some default parameters.
%	 Returns:
%	  MODEL - the model structure with the default parameters placed in.
%	 Arguments:
%	  MODEL - the model structure which requires initialisation.
%	
%
%	See also
%	MEUCREATE, MODELCREATE, MODELPARAMINIT


%	Copyright (c)  Neil D. Lawrence 2009
% 	meuParamInit.m SVN version 985
% 	last update 2010-05-26T05:49:09.000000Z

[model.indices, model.D2] = findNeighbours(model.Y, model.k);
model.kappa = ones(model.N, model.k);
model.gamma = 1e-4;
model.traceY = sum(sum(model.Y.*model.Y));
params = meuExtractParam(model);
model = meuExpandParam(model, params);